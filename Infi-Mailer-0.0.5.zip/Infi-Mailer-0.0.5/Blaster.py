import os
import csv
import random
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.utils import formatdate
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from dotenv import load_dotenv
import base64
import platform
from pyfiglet import Figlet

# Constants
EMAILS_PER_MINUTE = 10
DELAY_BETWEEN_EMAILS = 60 / EMAILS_PER_MINUTE
USERS_CSV = 'Elements/users.csv'
SENDERS_CSV = 'Elements/senders.csv'
SUBJECT_FILE = 'Elements/subject.txt'
BODY_TEMPLATE = 'Elements/body.html'
ATTACHMENT_TEMPLATE_DIR = 'PDF'
LOG_FILE = 'email_log.txt'

# Helper Functions
def log_message(message):
    with open(LOG_FILE, 'a') as log_file:
        log_file.write(message + '\n')
    print(message)

def generate_random_string(length, characters="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"):
    return ''.join(random.choice(characters) for _ in range(length))

def load_placeholders():
    return {
        "id": generate_random_string(14),
        "invc_number": generate_random_string(12),
        "order_number": generate_random_string(14),
        "product": fetch_random_line('Elements/data_product.csv'),
        "charges": fetch_random_line('Elements/data_charges.csv'),
        "quantity": fetch_random_line('Elements/data_quantity.csv'),
        "amount": fetch_random_line('Elements/data_charges.csv'),
        "date": fetch_random_line('Elements/data_date.csv'),
        "number": fetch_random_line('Elements/data_number.csv'),
    }

def fetch_random_line(file_path):
    try:
        if not os.path.exists(file_path):
            log_message(f"Error: File not found: {file_path}")
            return "DEFAULT_VALUE"

        with open(file_path, 'r') as file:
            lines = file.readlines()
            if not lines:
                log_message(f"Warning: File is empty: {file_path}")
                return "DEFAULT_VALUE"

        return random.choice(lines).strip()
    except Exception as e:
        log_message(f"Error reading file {file_path}: {e}")
        return "DEFAULT_VALUE"

def replace_placeholders(content, placeholders):
    for key, value in placeholders.items():
        content = content.replace(f"${key}", value)
    return content

def load_html_body():
    try:
        if not os.path.exists(BODY_TEMPLATE):
            log_message(f"Error: HTML body template not found: {BODY_TEMPLATE}")
            return "DEFAULT_HTML_BODY"

        with open(BODY_TEMPLATE, 'r') as file:
            html_content = file.read()
        return html_content
    except Exception as e:
        log_message(f"Error reading HTML body template: {e}")
        return "DEFAULT_HTML_BODY"

def generate_pdf_from_template(template_path, output_path, placeholders):
    try:
        with open(template_path, 'r') as template_file:
            html_content = template_file.read()

        html_content = replace_placeholders(html_content, placeholders)

        tmp_html_file = "temp.html"
        with open(tmp_html_file, "w") as tmp_file:
            tmp_file.write(html_content)

        os.system(f"wkhtmltopdf {tmp_html_file} {output_path}")
        os.remove(tmp_html_file)
    except Exception as e:
        log_message(f"Error generating PDF from template {template_path}: {e}")

def get_credentials(email):
    token_file = f'Tokens/{email}.json'
    credential_file = f'api_keys/{email}.json'

    creds = None
    if os.path.exists(token_file):
        creds = Credentials.from_authorized_user_file(token_file)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(credential_file, ['https://www.googleapis.com/auth/gmail.send'])
            creds = flow.run_local_server(port=0)
        with open(token_file, 'w') as token:
            token.write(creds.to_json())
    return creds

def send_email(sender, recipient, subject, body, attachment_path):
    try:
        credentials = get_credentials(sender['Email'])
        service = build('gmail', 'v1', credentials=credentials)

        msg = MIMEMultipart()
        msg['From'] = f"{sender['Name']} <{sender['Email']}>"
        msg['To'] = recipient
        msg['Subject'] = subject
        msg['Date'] = formatdate(localtime=True)
        msg.attach(MIMEText(body, 'html'))

        with open(attachment_path, 'rb') as file:
            part = MIMEApplication(file.read(), Name=os.path.basename(attachment_path))
            part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment_path)}"'
            msg.attach(part)

        raw_message = base64.urlsafe_b64encode(msg.as_bytes()).decode()
        service.users().messages().send(userId='me', body={'raw': raw_message}).execute()
        log_message(f"Email sent to {recipient} from {sender['Email']}")
    except Exception as e:
        log_message(f"Failed to send email to {recipient}: {e}")

# Main Function
# Main Function
def main():
    required_files = [
        USERS_CSV,
        SENDERS_CSV,
        SUBJECT_FILE,
        BODY_TEMPLATE,
        'Elements/data_product.csv',
        'Elements/data_charges.csv',
        'Elements/data_quantity.csv',
        'Elements/data_date.csv',
        'Elements/data_number.csv',
    ]
    for file in required_files:
        if not os.path.exists(file):
            log_message(f"Error: Required file missing: {file}")
            return

    if not os.path.exists(ATTACHMENT_TEMPLATE_DIR):
        log_message(f"Error: Attachment template directory missing: {ATTACHMENT_TEMPLATE_DIR}")
        return

    try:
        with open(SENDERS_CSV, 'r') as senders_file:
            senders = list(csv.DictReader(senders_file))
        if not senders:
            log_message("Error: No sender data found in senders.csv")
            return

        with open(USERS_CSV, 'r') as users_file:
            recipients = [row[0] for row in csv.reader(users_file)]
        if not recipients:
            log_message("Error: No recipient data found in users.csv")
            return
    except Exception as e:
        log_message(f"Error loading CSV files: {e}")
        return

    try:
        placeholders = load_placeholders()
        with open(SUBJECT_FILE, 'r') as file:
            subject_template = file.read()
        subject = replace_placeholders(subject_template, placeholders)
        html_body_template = load_html_body()
    except Exception as e:
        log_message(f"Error loading templates or placeholders: {e}")
        return

    for i, recipient in enumerate(recipients, start=1):
        try:
            sender = random.choice(senders)
            body = replace_placeholders(html_body_template, placeholders)

            attachment_path = f"Invoices/{placeholders['invc_number']}.pdf"
            template_file = os.path.join(ATTACHMENT_TEMPLATE_DIR, random.choice(os.listdir(ATTACHMENT_TEMPLATE_DIR)))
            generate_pdf_from_template(template_file, attachment_path, placeholders)
            send_email(sender, recipient, subject, body, attachment_path)

            # Remove recipient from users.csv after successful email
            recipients.remove(recipient)
            with open(USERS_CSV, 'w', newline='') as users_file:
                writer = csv.writer(users_file)
                for email in recipients:
                    writer.writerow([email])
        except Exception as e:
            log_message(f"Error processing email for {recipient}: {e}")

        if i % EMAILS_PER_MINUTE == 0:
            log_message("Rate limit reached. Pausing...")
            time.sleep(DELAY_BETWEEN_EMAILS)


if __name__ == "__main__":
    main()
